import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-createdriverform',
  templateUrl: './createdriverform.component.html',
  styleUrls: ['./createdriverform.component.scss']
})
export class CreatedriverformComponent implements OnInit {

  constructor() {
 
    
   

   }

  ngOnInit() {
  }

}
