import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listdriverform',
  templateUrl: './listdriverform.component.html',
  styleUrls: ['./listdriverform.component.scss']
})
export class ListdriverformComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
