import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewdriverform',
  templateUrl: './viewdriverform.component.html',
  styleUrls: ['./viewdriverform.component.scss']
})
export class ViewdriverformComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
