import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewccbookinglist',
  templateUrl: './viewccbookinglist.component.html',
  styleUrls: ['./viewccbookinglist.component.scss']
})
export class ViewccbookinglistComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
