import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewbookingestimation',
  templateUrl: './viewbookingestimation.component.html',
  styleUrls: ['./viewbookingestimation.component.scss']
})
export class ViewbookingestimationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
