import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listsubserviceform',
  templateUrl: './listsubserviceform.component.html',
  styleUrls: ['./listsubserviceform.component.scss']
})
export class ListsubserviceformComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
