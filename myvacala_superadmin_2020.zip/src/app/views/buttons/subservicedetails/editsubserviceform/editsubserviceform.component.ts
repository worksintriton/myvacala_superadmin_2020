import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editsubserviceform',
  templateUrl: './editsubserviceform.component.html',
  styleUrls: ['./editsubserviceform.component.scss']
})
export class EditsubserviceformComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
