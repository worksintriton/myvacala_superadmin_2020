import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewmachanicform',
  templateUrl: './viewmachanicform.component.html',
  styleUrls: ['./viewmachanicform.component.scss']
})
export class ViewmachanicformComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
