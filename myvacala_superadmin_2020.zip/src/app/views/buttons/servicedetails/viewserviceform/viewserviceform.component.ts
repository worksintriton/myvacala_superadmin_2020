import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewserviceform',
  templateUrl: './viewserviceform.component.html',
  styleUrls: ['./viewserviceform.component.scss']
})
export class ViewserviceformComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
