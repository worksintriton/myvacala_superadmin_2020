import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accessroll',
  templateUrl: './accessroll.component.html',
  styleUrls: ['./accessroll.component.scss']
})
export class AccessrollComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
