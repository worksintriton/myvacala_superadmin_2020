import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminusercreate',
  templateUrl: './adminusercreate.component.html',
  styleUrls: ['./adminusercreate.component.scss']
})
export class AdminusercreateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
