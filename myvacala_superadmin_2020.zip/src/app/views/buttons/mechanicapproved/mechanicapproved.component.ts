import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mechanicapproved',
  templateUrl: './mechanicapproved.component.html',
  styleUrls: ['./mechanicapproved.component.scss']
})
export class MechanicapprovedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
