export const environment = {
  production: true,

  apiUrl: 'https://myvacala.com/api/',
  imageURL: 'https://myvacala.com/api/'
  // apiUrl: 'http://15.207.51.203:3000/',
  // imageURL: 'http://15.207.51.203:3000/'

};