export const environment = {
  production: true,
  // 34.221.117.87:3000

  // 34.211.194.144:3000

  //  apiUrl: 'http://54.214.141.11:3000/',
  //  imageURL: 'http://54.214.141.11:3000/'

  apiUrl: 'http://15.207.51.203:3000/',
  imageURL: 'http://15.207.51.203:3000/'

  // apiUrl: 'http://localhost:91/'
};