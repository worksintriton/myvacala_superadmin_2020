import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listparking',
  templateUrl: './listparking.component.html',
  styleUrls: ['./listparking.component.scss']
})
export class ListparkingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
