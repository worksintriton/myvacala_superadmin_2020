import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewccparkingbookinglist',
  templateUrl: './viewccparkingbookinglist.component.html',
  styleUrls: ['./viewccparkingbookinglist.component.scss']
})
export class ViewccparkingbookinglistComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
