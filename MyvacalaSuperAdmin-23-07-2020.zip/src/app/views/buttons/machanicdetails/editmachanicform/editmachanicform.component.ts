import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editmachanicform',
  templateUrl: './editmachanicform.component.html',
  styleUrls: ['./editmachanicform.component.scss']
})
export class EditmachanicformComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
