import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mechanicbookings',
  templateUrl: './mechanicbookings.component.html',
  styleUrls: ['./mechanicbookings.component.scss']
})
export class MechanicbookingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
