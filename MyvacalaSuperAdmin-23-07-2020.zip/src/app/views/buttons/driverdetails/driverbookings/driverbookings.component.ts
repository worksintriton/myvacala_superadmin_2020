import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-driverbookings',
  templateUrl: './driverbookings.component.html',
  styleUrls: ['./driverbookings.component.scss']
})
export class DriverbookingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
