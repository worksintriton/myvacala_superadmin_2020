import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editdriverform',
  templateUrl: './editdriverform.component.html',
  styleUrls: ['./editdriverform.component.scss']
})
export class EditdriverformComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
