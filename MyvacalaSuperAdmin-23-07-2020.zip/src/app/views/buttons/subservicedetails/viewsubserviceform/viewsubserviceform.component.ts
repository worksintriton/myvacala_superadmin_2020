import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewsubserviceform',
  templateUrl: './viewsubserviceform.component.html',
  styleUrls: ['./viewsubserviceform.component.scss']
})
export class ViewsubserviceformComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
