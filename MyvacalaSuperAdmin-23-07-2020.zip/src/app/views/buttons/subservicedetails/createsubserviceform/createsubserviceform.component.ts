import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-createsubserviceform',
  templateUrl: './createsubserviceform.component.html',
  styleUrls: ['./createsubserviceform.component.scss']
})
export class CreatesubserviceformComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
