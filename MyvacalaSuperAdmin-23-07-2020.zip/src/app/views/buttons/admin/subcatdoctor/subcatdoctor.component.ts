import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-subcatdoctor',
  templateUrl: './subcatdoctor.component.html',
  styleUrls: ['./subcatdoctor.component.scss']
})
export class SubcatdoctorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
