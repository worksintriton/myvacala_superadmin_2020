import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminuserlist',
  templateUrl: './adminuserlist.component.html',
  styleUrls: ['./adminuserlist.component.scss']
})
export class AdminuserlistComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
